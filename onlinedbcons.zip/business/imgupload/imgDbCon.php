<?php
// Database configuration
$dbHost     = "mysql70.unoeuro.com";
$dbUsername = "madum_eu";
$dbPassword = "teacherpassword";
$dbName     = "madum_eu_db";

// Create database connection
$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
?>