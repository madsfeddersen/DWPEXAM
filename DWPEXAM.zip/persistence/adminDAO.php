<?php


// Description CRUD

function createDescription() {

}

function readDescription() {
    
}

function updateDescription() {
    
}

function deleteDescription() {
    
}


// Opening Hours CRUD

function createOpeningHours() {

}

function readOpeningHours() {
    
}

function updateOpeningHours() {
    
}

function deleteOpeningHours() {
    
}


// Contact Information CRUD

function createContact() {

}

function readContact() {

}

function updateContact() {

}


function deleteContact() {

}


// CRUD for Daily offer / special product for home page

function createOffer() {

}

function readOffer() {

}

function updateOffer() {

}


function deleteOffer() {

}


// News posts CRUD

function createNewsPost() {

}

function readNewsPost() {

}

function updateNewsPost() {

}


function deleteNewsPost() {

}


?>