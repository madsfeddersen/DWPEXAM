<?php

function createUser() {

}

function readUser() {
    
}

function updateUser() {
    
}

function deleteUser() {
    
}

?>