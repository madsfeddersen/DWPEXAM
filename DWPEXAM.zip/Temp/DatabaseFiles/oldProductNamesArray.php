<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 4.8.4
 */

/**
 * Database `duckshopdb`
 */

/* `duckshopdb`.`products` */
$products = array(
  array('id' => '1','name' => 'Standard Duck','price' => '10.00'),
  array('id' => '2','name' => 'Mermaid Duck','price' => '32.95'),
  array('id' => '3','name' => 'Arnold Duck','price' => '12.00'),
  array('id' => '4','name' => 'Sunglasses Duck','price' => '10.00'),
  array('id' => '5','name' => 'Donald Trump Duck','price' => 'Billions'),
  array('id' => '6','name' => 'Turtle Duck','price' => '5.00'),
  array('id' => '7','name' => 'Bat Duck','price' => '25.00'),
  array('id' => '8','name' => 'Female Duck','price' => '47.00'),
  array('id' => '9','name' => 'Ninja Duck','price' => '25.00'),
  array('id' => '10','name' => 'Dansken Duck','price' => '500 Jyske$'),
  array('id' => '11','name' => 'Faggot Duck','price' => 'Free'),
  array('id' => '12','name' => 'DeeJay DucklinG','price' => 'ffffff'),
  array('id' => '13','name' => 'Grandma Duck','price' => '97.00')
);
