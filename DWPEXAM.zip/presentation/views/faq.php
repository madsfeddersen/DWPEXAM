<head>
    <style>
    #footer {
        position: relative;
    }
    </style>
</head>

<br>
<h1 class="page-title">Frequently asked questions</h1>
<br>

<div class="faq-box">
<h3 class="faq-h3"> Question: Can you eat the ducks?</h3>
<br>
<h3 class="faq-h3">Answer: Well... technically yes, but you probably will not be feeling too well afterwards. </h3>
<br>
<h6 class="faq-h6">Duck You© is not resposible for any harm or casualties that might occur due to the ingestion of our rubber ducks.</h6>
</div>
<br>
<br>
<div class="faq-box">
<h3 class="faq-h3"> Question: Are the ducks vegan?</h3>
<br>
<h3 class="faq-h3">Answer: No, they are actually carnivores.</h3>
</div>
<br>
<br>
<div class="faq-box">
<h3 class="faq-h3"> Question: Can the ducks do any trick?</h3>
<br>
<h3 class="faq-h3">Answer: Yes, they are actually world champions of the famous move "The Sitting Duck"!</h3>
</div>
<br>
<br>
<div class="faq-box">
<h3 class="faq-h3"> Question: Is "Duck You" a play on "Fuck You"? </h3>
<br>
<h3 class="faq-h3">Answer: No, not at all! This is pure coincidence!</h3>
</div>
