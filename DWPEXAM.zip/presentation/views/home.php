<br>
<h1 class="page-title">Home</h1>
<h1>Placeholder for news / special offer section</h1>