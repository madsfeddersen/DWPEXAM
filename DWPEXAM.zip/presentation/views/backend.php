<br>
<h1 class="page-title">Welcome to the backend.</h1>
<h1><- Admin controlpanel -></h1>
<h4>L33T Butt0Nz not found</h4>

<br>
<div style="text-align:left;">
<ul>Implement this stuff:
    <li>
       Order overview 
    </li>
    <li>
       Invoice creator
    </li>
    <li>
    He should at least be able to update (CRUD) these pieces of information: o Description of the company o Opening hours o Contact information o The products o Daily special (product) on the front page o The news
    </li>
</ul>
</div>