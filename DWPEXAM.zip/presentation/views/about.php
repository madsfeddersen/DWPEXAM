<br>
<h1 class="page-title">About DuckYou!</h1>
<br><p class="page-text">Hi there, and welcome to our webshop!
<br><br>We are your number 1 stop for everything related to Rubber Ducks!
<br><br>Since our start way back in 2019 we have been supplying the world with our high quality Rubber Ducks.
<br><br>The company consists of two owners, Andreas Madum and Mads Christian Feddersen, who both have a lot of knowledge
<br><br>about rubber ducks. (Insert facts from Wikipedia - remember to delete this)We guarantee 100% satisfaction.
<br><br>Without further ado, DuckYou! :P</p>