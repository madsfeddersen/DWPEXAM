<footer class="footer-distributed">
        <div class="footer-right">
            <a href="https://www.facebook.com/KimThoeisen" target="_blank"><i class="fab fa-facebook-f"></i></a>
            <a href="https://www.linkedin.com/in/kim-th%C3%B8isen/" target="_blank"><i class="fab fa-linkedin"></i></a>
            <a href="https://github.com/madsfeddersen/DWPEXAM" target="_blank"><i class="fab fa-github"></i></a>
        </div>
        <div class="footer-left">
            <p class="footer-links">
                <a href="/home">Home</a> |
                <a href="/shop">Shop</a> |
                <a href="/about">About us</a> |
                <a href="/faq">FAQ</a> |
                <a href="/contact">Contact</a>
            </p>
            <br>
            <p class="footer-text">
                We are your number one stop for rubber ducks.
            </p> 
            <br>
            <p class="footer-text">
                We've got all shapes, colors and sizes of duck
                that you could possibly think of!
            </p>
            <br>
            <p class="footer-text">
                Perfect for your bath time needs! 
            </p>
            <br>
            <p class="footer-text">
                Our ducks are sure to make you go quackers!
            </p>
            <br>
            <p class="footer-text">
                Treat yourself, you ducking duck!
            </p>
            <br>
            <br>
            <p class="copyright">
                Duck You! 	&copy;2019
            </p>
        </div>
    </footer>

   