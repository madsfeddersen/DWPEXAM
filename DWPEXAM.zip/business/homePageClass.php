<?php

class echoText {

    public function __construct()
    {
        
    }
    
    public function echoNews()
    {
		echo "News";
    }

    public function echoDescription()
    {
		echo "Who are we?";
    }
}